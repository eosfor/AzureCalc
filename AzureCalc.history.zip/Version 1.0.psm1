function Get-AzureCalcTier($AzureCalcData = $script:rawdata) {
  $AzureCalcData.Tiers
}

function Get-AzureCalcType($AzureCalcData = $script:rawdata) {
  $AzureCalcData.Types
}

function Get-AzureCalcSize($AzureCalcData = $script:rawdata) {
  $AzureCalcData.Sizes
}

function Get-AzureCalcSoftwareLicense($AzureCalcData = $script:rawdata) {
  $AzureCalcData.softwareLicenses
}

function Get-AzureCalcRegion($AzureCalcData = $script:rawdata) {
  $AzureCalcData.regions
}

function Get-AzureCalcData {
  [CmdletBinding()]
  param()
  $request = Invoke-WebRequest -Uri https://azure.microsoft.com/api/v1/pricing/virtual-machines/calculator/?culture=en-us
  $script:rawdata = $offers = $request.Content | ConvertFrom-Json
  
  foreach ($type in Get-AzureCalcType  -AzureCalcData $offers) {
    foreach ($size in Get-AzureCalcSize -AzureCalcData $offers) {
        foreach ($tier in Get-AzureCalcTier -AzureCalcData $offers) {
            $indexName = "$($type.slug)-$($size.slug)-$($tier.slug)"
            if ($offers.offers.$indexName) {
            [pscustomobject]@{
                Cores = $offers.offers.$indexName.cores
                Ram = $offers.offers.$indexName.Ram
                DiskSize = $offers.offers.$indexName.DiskSize
                Prices = $offers.offers.$indexName.Prices
                Skus = $offers.offers.$indexName.Skus
                Type = $type.slug
                Size = $size.slug
                Tier = $tier.slug
                Index = $indexName
            }
            }
        }
    }
  }

}

function Get-AzureCalcPrice {
  [cmdletbinding()]
  param (
    [int]$CPU, 
    [int]$RAM,
    [ValidateScript({$_ -in (Get-AzureCalcType).slug})]
    [string]$Type,
    [ValidateScript({$_ -in (Get-AzureCalcSize).slug})]
    [string]$Size,
    [ValidateScript({$_ -in (Get-AzureCalcRegion).slug})]
    [string[]]$Region, 
    $CalcData
  )
  begin{
    $cpuFilter = {param($objectSet)  $objectSet | ? {$_.Cores -eq $CPU} } 
    $ramFilter = {param($objectSet)  $objectSet | ? {$_.Ram -eq $RAM} }
    $typeFilter = {param($objectSet)  $objectSet | ? {$_.Type -eq $Type} }
    $sizeFilter = {param($objectSet)  $objectSet | ? {$_.Size -eq $Size} }
    $regionFilter = {param($objectSet)  $objectSet | ? { [bool]$r -OR ($Region | % {$_.Prices.keys -contains $_ }); $r } } 
  }
  process{
    $filters = @()
    if ($CPU){
      $filters += $cpuFilter
    }
    if ($RAM){
      $filters += $ramFilter
    }
    if ($Type){
      $filters += $typeFilter
    }
    if ($Size){
      $filters += $sizeFilter 
    }
    
    if ($Region){
      $filters += $regionFilter 
    }
    
    $ret = $CalcData
    foreach ($f in $filters){
      $ret = & $f $ret
    }
    
    if ($Region) {
      foreach ($el in $ret) {
        $res =  [ordered]@{
          Index = $el.index
          Type = $el.type
          Size = $el.size
          Cores = $el.Cores
          Ram = $el.Ram
          DiskSize = $el.DiskSize          
        }
          
        foreach ($r in $Region){
          $res.$r = $el.Prices.$r
        }
          
        [pscustomobject] $res
      }
    }
    else{
      $ret
    }
  }
}
